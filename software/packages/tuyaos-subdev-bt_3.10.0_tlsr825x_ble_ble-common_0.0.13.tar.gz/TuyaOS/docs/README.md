## 资料获取

[TuyaOS 开发者论坛 - 蓝牙设备开发 - 资料汇总帖子](https://www.tuyaos.com/viewtopic.php?t=12)

