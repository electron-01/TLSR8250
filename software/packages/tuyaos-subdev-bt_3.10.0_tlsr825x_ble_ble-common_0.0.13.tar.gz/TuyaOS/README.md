## 文件解析

.ide_tool，工具脚本，用户无需关心

**.log，Keil等IDE的工程所在目录，含编译产物**

**_output，编译最终产物，从.log子目录中拷贝出来**

**apps，基础例程或产品所在目录**

build，宏配置中间产物

**components，SDK组件所在目录**

**docs，文档资料所在目录**

**include，SDK头文件所在目录**

**libs，SDK库文件所在目录**

scripts，工具脚本，用户无需关心

tools，用户无需关心

**vender，芯片原厂SDK所在目录**

build_app.py，工具脚本，用户无需关心

**CHANGELOG.md，版本记录**

ci_autobuild.sh，工具脚本，用户无需关心

ci_autopack.sh，工具脚本，用户无需关心

prepare.sh，工具脚本，用户无需关心

project.json，工具脚本产物，用户无需关心

README.md，本文档

## 资料获取

[TuyaOS 开发者论坛 - 蓝牙设备开发 - 资料汇总帖子](https://www.tuyaos.com/viewtopic.php?t=12)



