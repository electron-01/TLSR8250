#ifndef _GCC_WRAP_STDINT_H
#if __STDC_HOSTED__
//# include_next <stdint.h>
# include "stdint-gcc.h"
#else
# include "stdint-gcc.h"
#endif
#define _GCC_WRAP_STDINT_H
#endif
